// Alias de entrada para tiendas externas: POST /api/webhook
export { default } from './tickets/index.js';
