create table if not exists public.tickets (id text primary key, number text not null, date timestamptz not null default now(), data jsonb not null);
create index if not exists tickets_date_idx on public.tickets(date desc);
alter table public.tickets enable row level security;
