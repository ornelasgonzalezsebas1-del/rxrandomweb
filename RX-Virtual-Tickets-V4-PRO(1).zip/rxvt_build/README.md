# RX Virtual Tickets V4

Web profesional para generar **tickets físicos digitales, facturas, recibos y cotizaciones**. Preparada para Vercel.

## Incluye
- Ticket estilo físico/thermal.
- QR único al final del ticket.
- Debajo del QR aparece la URL y después la dirección del negocio.
- PDF real generado en el navegador.
- PNG real.
- Impresión.
- Número de factura, serie, folio, fecha y vencimiento.
- Cliente, RFC/ID fiscal, email y dirección.
- Productos/servicios, cantidades y precios.
- IVA, descuento, envío, subtotal y total.
- Estado: Pagado, Pendiente, Cancelado, Vencido.
- Método de pago y número de pedido.
- Logo por URL o subida de imagen.
- Nombre, subtítulo, dirección, ciudad, teléfono, RFC, email, moneda y pie del ticket.
- URL pública `/t/ID`.
- Historial local para comprobantes manuales.
- Base de datos Supabase para comprobantes creados por tiendas externas.
- API universal `POST /api/tickets`.
- Adaptador Shopify `POST /api/shopify`.
- Adaptador WooCommerce `POST /api/woocommerce`.
- Webhook de salida.
- Compatible con Vercel sin servidor adicional.

## Vercel + Supabase

1. Crea un proyecto en Supabase.
2. Abre SQL Editor y ejecuta `schema.sql`.
3. En Vercel crea estas variables:
   - `SUPABASE_URL`
   - `SUPABASE_SERVICE_ROLE_KEY`
   - `RX_TICKETS_SECRET`
   - `PUBLIC_BASE_URL`
4. Opcionales:
   - `SHOPIFY_WEBHOOK_SECRET`
   - `WOOCOMMERCE_WEBHOOK_SECRET`
   - `SHOPIFY_STORE_NAME`
   - `WOOCOMMERCE_STORE_NAME`
   - `STORE_LOGO_URL`
5. Haz Deploy/Redeploy.

**Nunca pongas `SUPABASE_SERVICE_ROLE_KEY` en el HTML ni en el navegador.**

## Conectar Shopify

En Shopify crea un webhook de pedidos pagados (`Order payment`) y usa:

`https://TU-DOMINIO.vercel.app/api/shopify`

Protección recomendada:

`X-RX-Secret: TU_RX_TICKETS_SECRET`

El adaptador recibe productos, cliente, pedido, estado y moneda y los transforma en un ticket RX.

## Conectar WooCommerce

En WooCommerce crea un webhook de pedido creado/pagado y usa:

`https://TU-DOMINIO.vercel.app/api/woocommerce`

Usa:

`X-RX-Secret: TU_RX_TICKETS_SECRET`

También puedes definir `WOOCOMMERCE_WEBHOOK_SECRET` en Vercel.

## API universal

Endpoint:

`POST https://TU-DOMINIO.vercel.app/api/tickets`

Header:

`Authorization: Bearer TU_RX_TICKETS_SECRET`

Ejemplo:

```json
{
  "number": "FAC-000123",
  "type": "invoice",
  "customer": {
    "name": "Juan Pérez",
    "rfc": "XAXX010101000",
    "email": "cliente@example.com"
  },
  "items": [
    {"name": "Producto", "qty": 2, "price": 99}
  ],
  "iva": 16,
  "discount": 10,
  "shipping": 50,
  "payment": "Tarjeta",
  "status": "Pagado",
  "orderId": "123",
  "qrUrl": "https://tuweb.com/pedido/123"
}
```

La respuesta devuelve `id`, `number`, `url` y `ticket`.

## Importante sobre facturación fiscal

Esta aplicación genera **comprobantes/tickets visuales y documentos PDF**, no sustituye la facturación electrónica oficial del SAT. Para CFDI fiscal real necesitarías integrar un PAC/servicio de timbrado y cumplir sus requisitos.

## Vercel

No requiere `npm install`. Es una aplicación HTML/JS + funciones serverless.

Puedes importar el proyecto directamente desde GitHub o subir esta carpeta a Vercel.
